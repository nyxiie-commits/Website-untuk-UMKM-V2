<?php
namespace App\Core;
final class Auth {
    public static function check(): bool { return isset($_SESSION['user']['id']); }
    public static function isAdmin(): bool { return self::check() && ($_SESSION['user']['role'] ?? '') === 'admin'; }
    public static function id(): ?int { return self::check() ? (int)$_SESSION['user']['id'] : null; }
}
