<?php
namespace App\Core;
abstract class Controller {
    protected function view(string $name, array $data = []): void { View::render($name, $data); }
    protected function redirect(string $path): never { header('Location: ' . url($path)); exit; }
}
