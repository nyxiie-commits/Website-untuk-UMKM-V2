KARYAKITA - PANDUAN DEPLOY INFINITYFREE

1. Upload isi folder ZIP ini ke htdocs (bukan folder karyakita bersarang) melalui File Manager.
2. Buat MySQL Database di InfinityFree Control Panel > MySQL Databases.
3. Buka phpMyAdmin dari panel InfinityFree, pilih database yang dibuat, lalu Import file database.sql.
4. Edit config.php: DB_HOST, DB_NAME, DB_USER, DB_PASS sesuai detail MySQL InfinityFree. Jangan gunakan localhost pada hosting.
5. Pastikan folder uploads/products dan uploads/payments dapat ditulisi (permission umumnya 755; bila upload gagal cek permission).
6. Buka domain. Buat akun pelanggan dari menu Daftar.
7. Untuk admin: setelah registrasi akun, jalankan query berikut di phpMyAdmin dengan mengganti EMAIL_ADMIN:
   UPDATE users SET role='admin' WHERE email='EMAIL_ADMIN';
   Logout lalu login kembali. Jangan pernah menyediakan pendaftaran admin publik.
8. Edit rekening contoh di payment.php sebelum menerima pembayaran sungguhan.

CATATAN FITUR
- Checkout memerlukan login. Pengunjung tetap dapat melihat katalog dan memasukkan item ke keranjang.
- Bukti pembayaran JPG/PNG/PDF maksimal 3 MB. Admin menyetujui/menolak di admin/pesanan.php.
- Rekomendasi saat ini adalah baseline kemiripan kategori dan rentang harga. Ini belum diklaim sebagai metode final skripsi; sesuaikan setelah metode penelitian disetujui.
- Produk handmade lintas kategori; kategori dikelola dinamis dari dashboard.
- Gunakan HTTPS. Ganti rekening demo dan jangan simpan password database di tempat publik.

FITUR STRUK PEMBAYARAN:
- Setelah admin menyetujui bukti pembayaran, pelanggan dapat membuka Pesanan Saya lalu klik Cetak / Lihat Struk.
- Struk menampilkan nomor pesanan, tanggal pembayaran, pelanggan, rincian produk, total dibayar, dan status verifikasi.
- Tombol Cetak / Simpan PDF menggunakan fitur print browser.
- Admin juga dapat membuka struk dari halaman Pesanan & Verifikasi.
- Jika database sudah pernah di-import sebelum kolom paid_at ditambahkan, jalankan SQL ini di phpMyAdmin: ALTER TABLE orders ADD COLUMN paid_at DATETIME NULL AFTER payment_status;
