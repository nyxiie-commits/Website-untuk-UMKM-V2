<?php
require_once __DIR__.'/config.php';
function e($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
function url($p=''){return BASE_URL.'/'.ltrim($p,'/');}
function go($p){header('Location: '.url($p));exit;}
function user(){return $_SESSION['user']??null;}
function need_login(){if(!user()){$_SESSION['after_login']=$_SERVER['REQUEST_URI']??url('');go('login.php?required=1');}}
function need_admin(){need_login();if(user()['role']!=='admin'){http_response_code(403);exit('Akses khusus admin.');}}
function rupiah($n){return 'Rp'.number_format((float)$n,0,',','.');}
function flash($m=null){if($m!==null){$_SESSION['flash']=$m;return;} $x=$_SESSION['flash']??'';unset($_SESSION['flash']);return $x;}
function image_url($name){return $name && file_exists(__DIR__.'/uploads/products/'.$name)?url('uploads/products/'.$name):'https://placehold.co/600x450/fff3c4/7b4b16?text=KaryaKita';}
function recommend_products($pdo,$productId=null,$limit=4){
  // Rekomendasi awal berbasis kemiripan kategori dan rentang harga; modul dapat diganti sesuai metode skripsi.
  if($productId){$s=$pdo->prepare('SELECT * FROM products WHERE id=?');$s->execute([$productId]);$base=$s->fetch();if(!$base)return [];
    $s=$pdo->prepare("SELECT p.*, c.name category_name, (CASE WHEN p.category_id=? THEN 5 ELSE 0 END + CASE WHEN p.price BETWEEN ? AND ? THEN 2 ELSE 0 END) score FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.id<>? AND p.stock>0 ORDER BY score DESC,p.created_at DESC LIMIT ?");
    $s->bindValue(1,$base['category_id'],PDO::PARAM_INT);$s->bindValue(2,max(0,$base['price']*.7));$s->bindValue(3,$base['price']*1.3);$s->bindValue(4,$productId,PDO::PARAM_INT);$s->bindValue(5,$limit,PDO::PARAM_INT);$s->execute();return $s->fetchAll();
  }
  return $pdo->query("SELECT p.*,c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.stock>0 ORDER BY p.created_at DESC LIMIT ".(int)$limit)->fetchAll();
}
