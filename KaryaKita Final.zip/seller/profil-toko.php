<?php
require_once __DIR__ . '/auth.php';

$uid = (int) user()['id'];
$error = '';
$success = '';

$q = $pdo->prepare("SELECT id,name,store_name,store_description,store_address,store_phone,store_logo,store_banner
                    FROM users WHERE id=? AND role='seller' LIMIT 1");
$q->execute([$uid]);
$store = $q->fetch(PDO::FETCH_ASSOC);
if (!$store) {
    http_response_code(404);
    exit('Data toko tidak ditemukan.');
}

function store_upload_file(string $field, string $prefix): ?string {
    if (empty($_FILES[$field]['name'])) return null;
    if (!isset($_FILES[$field]) || $_FILES[$field]['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Upload gambar gagal. Silakan pilih ulang file.');
    }
    if ((int)$_FILES[$field]['size'] > 2 * 1024 * 1024) {
        throw new RuntimeException('Ukuran gambar maksimal 2 MB.');
    }
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($_FILES[$field]['tmp_name']);
    $types = ['image/jpeg'=>'jpg', 'image/png'=>'png', 'image/webp'=>'webp'];
    if (!isset($types[$mime])) {
        throw new RuntimeException('Format gambar harus JPG, PNG, atau WebP.');
    }
    $filename = $prefix . '_' . bin2hex(random_bytes(12)) . '.' . $types[$mime];
    $dir = __DIR__ . '/../uploads/store/';
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        throw new RuntimeException('Folder penyimpanan gambar toko tidak tersedia.');
    }
    if (!move_uploaded_file($_FILES[$field]['tmp_name'], $dir . $filename)) {
        throw new RuntimeException('Gambar gagal disimpan. Periksa izin folder uploads/store.');
    }
    return $filename;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $storeName = trim($_POST['store_name'] ?? '');
    $description = trim($_POST['store_description'] ?? '');
    $address = trim($_POST['store_address'] ?? '');
    $phone = trim($_POST['store_phone'] ?? '');

    if ($storeName === '' || mb_strlen($storeName) > 160) {
        $error = 'Nama toko wajib diisi dan maksimal 160 karakter.';
    } elseif (mb_strlen($description) > 5000 || mb_strlen($address) > 255 || mb_strlen($phone) > 30) {
        $error = 'Deskripsi, alamat, atau nomor kontak melebihi batas karakter.';
    } else {
        $newLogo = null;
        $newBanner = null;
        try {
            $newLogo = store_upload_file('store_logo', 'logo');
            $newBanner = store_upload_file('store_banner', 'banner');

            $logo = $newLogo ?: $store['store_logo'];
            $banner = $newBanner ?: $store['store_banner'];

            $u = $pdo->prepare("UPDATE users
                SET store_name=?,store_description=?,store_address=?,store_phone=?,store_logo=?,store_banner=?
                WHERE id=? AND role='seller'");
            $u->execute([
                $storeName,
                $description !== '' ? $description : null,
                $address !== '' ? $address : null,
                $phone !== '' ? $phone : null,
                $logo,
                $banner,
                $uid
            ]);

            // Sinkronkan nama toko di session agar header langsung berubah.
            $_SESSION['user']['store_name'] = $storeName;

            $uploadDir = __DIR__ . '/../uploads/store/';
            if ($newLogo && !empty($store['store_logo'])) {
                $old = $uploadDir . basename($store['store_logo']);
                if (is_file($old)) @unlink($old);
            }
            if ($newBanner && !empty($store['store_banner'])) {
                $old = $uploadDir . basename($store['store_banner']);
                if (is_file($old)) @unlink($old);
            }

            flash('Profil toko berhasil diperbarui.');
            header('Location: profil-toko.php');
            exit;
        } catch (Throwable $e) {
            if ($newLogo && is_file(__DIR__ . '/../uploads/store/' . basename($newLogo))) {
                @unlink(__DIR__ . '/../uploads/store/' . basename($newLogo));
            }
            if ($newBanner && is_file(__DIR__ . '/../uploads/store/' . basename($newBanner))) {
                @unlink(__DIR__ . '/../uploads/store/' . basename($newBanner));
            }
            $error = $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Profil toko gagal disimpan. Pastikan migrasi profil toko sudah dijalankan.';
            error_log('[KaryaKita store profile] ' . $e->getMessage());
        }
    }
    // Tampilkan input terbaru setelah validasi gagal.
    $store['store_name'] = $storeName;
    $store['store_description'] = $description;
    $store['store_address'] = $address;
    $store['store_phone'] = $phone;
}

$pageTitle = 'Profil Toko';
require 'header.php';
$notice = flash();
$logoUrl = !empty($store['store_logo']) ? '../uploads/store/' . rawurlencode(basename($store['store_logo'])) : '';
$bannerUrl = !empty($store['store_banner']) ? '../uploads/store/' . rawurlencode(basename($store['store_banner'])) : '';
?>
<h1 class="h3 mb-3">Profil Toko</h1>
<p class="seller-muted mb-4">Atur identitas dan informasi toko yang akan digunakan pada halaman marketplace.</p>

<?php if ($notice): ?><div class="alert alert-success"><?=e($notice)?></div><?php endif; ?>
<?php if ($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?>

<section class="seller-panel">
    <h2 class="h5 mb-3">Pratinjau identitas toko</h2>
    <?php if ($bannerUrl): ?>
        <img src="<?=e($bannerUrl)?>" alt="Banner toko" style="width:100%;height:170px;object-fit:cover;border-radius:12px;margin-bottom:14px">
    <?php else: ?>
        <div style="height:120px;background:linear-gradient(120deg,#fff1c7,#f8d89b);border-radius:12px;margin-bottom:14px;display:grid;place-items:center;color:#765b3e">Banner toko belum dipasang</div>
    <?php endif; ?>
    <div class="d-flex align-items-center gap-3">
        <?php if ($logoUrl): ?>
            <img src="<?=e($logoUrl)?>" alt="Logo toko" style="width:76px;height:76px;object-fit:cover;border-radius:14px;border:1px solid #eadfc9">
        <?php else: ?>
            <div style="width:76px;height:76px;border-radius:14px;background:#fff1c7;display:grid;place-items:center;font-size:28px;color:#765b3e"><i class="bi bi-shop"></i></div>
        <?php endif; ?>
        <div><h3 class="h5 mb-1"><?=e($store['store_name'] ?: $store['name'])?></h3><div class="seller-muted"><?=e($store['store_phone'] ?: 'Nomor kontak belum diisi')?></div></div>
    </div>
</section>

<section class="seller-panel">
    <h2 class="h5 mb-3">Ubah informasi toko</h2>
    <form method="post" enctype="multipart/form-data" class="seller-form">
        <?=csrf_field()?>
        <label style="grid-column:1/-1">Nama toko
            <input type="text" name="store_name" maxlength="160" required value="<?=e($store['store_name'] ?? '')?>" placeholder="Contoh: Toko Handmade Maria">
        </label>
        <label style="grid-column:1/-1">Deskripsi toko
            <textarea name="store_description" rows="4" maxlength="5000" placeholder="Ceritakan produk dan keunikan toko Anda"><?=e($store['store_description'] ?? '')?></textarea>
        </label>
        <label>Nomor WhatsApp / Kontak
            <input type="text" name="store_phone" maxlength="30" value="<?=e($store['store_phone'] ?? '')?>" placeholder="Contoh: 08xxxxxxxxxx">
        </label>
        <label>Alamat toko
            <input type="text" name="store_address" maxlength="255" value="<?=e($store['store_address'] ?? '')?>" placeholder="Kota / alamat toko">
        </label>
        <label>Logo toko (JPG, PNG, WebP; maks. 2 MB)
            <input type="file" name="store_logo" accept="image/jpeg,image/png,image/webp">
        </label>
        <label>Banner toko (JPG, PNG, WebP; maks. 2 MB)
            <input type="file" name="store_banner" accept="image/jpeg,image/png,image/webp">
        </label>
        <div class="seller-actions" style="grid-column:1/-1">
            <button type="submit" class="btn btn-warning"><i class="bi bi-save"></i> Simpan Profil Toko</button>
            <a href="index.php" class="btn btn-outline-secondary">Kembali ke Dashboard</a>
        </div>
    </form>
</section>
<?php require 'footer.php'; ?>
