<?php
require_once __DIR__ . '/auth.php';

$uid = (int) user()['id'];
$error = '';

/*
 * Seller hanya boleh memproses pesanan yang seluruh item-nya dimiliki
 * oleh seller yang sedang login. Checkout terbaru memisahkan pesanan
 * berdasarkan pemilik produk, sehingga satu pesanan tidak bercampur toko.
 */
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
    $orderId = (int) ($_POST['id'] ?? 0);
    $action = (string) ($_POST['action'] ?? '');

    if ($orderId <= 0 || !order_belongs_to_seller($pdo, $orderId, $uid)) {
        $error = 'Pesanan ini bukan milik toko Anda.';
    } else {
        try {
            if ($action === 'approve') {
                $stmt = $pdo->prepare(
                    "UPDATE orders
                     SET payment_status = 'berhasil',
                         order_status = 'diproses',
                         paid_at = NOW()
                     WHERE id = ? AND payment_status = 'menunggu_verifikasi'"
                );
                $stmt->execute([$orderId]);
            } elseif ($action === 'reject') {
                $stmt = $pdo->prepare(
                    "UPDATE orders
                     SET payment_status = 'ditolak',
                         order_status = 'menunggu_pembayaran'
                     WHERE id = ? AND payment_status = 'menunggu_verifikasi'"
                );
                $stmt->execute([$orderId]);
            } elseif ($action === 'ship') {
                $stmt = $pdo->prepare(
                    "UPDATE orders
                     SET order_status = 'dikirim'
                     WHERE id = ?
                       AND payment_status = 'berhasil'
                       AND order_status = 'diproses'"
                );
                $stmt->execute([$orderId]);
            } elseif ($action === 'complete') {
                $stmt = $pdo->prepare(
                    "UPDATE orders
                     SET order_status = 'selesai'
                     WHERE id = ?
                       AND payment_status = 'berhasil'
                       AND order_status = 'dikirim'"
                );
                $stmt->execute([$orderId]);
            } else {
                $error = 'Aksi pesanan tidak dikenali.';
            }

            if ($error === '') {
                flash(
                    $stmt->rowCount() > 0
                        ? 'Status pesanan toko berhasil diperbarui.'
                        : 'Tidak ada perubahan. Periksa status pesanan saat ini.'
                );
                header('Location: pesanan.php');
                exit;
            }
        } catch (PDOException $e) {
            error_log('[KaryaKita seller pesanan] ' . $e->getMessage());
            $error = 'Status pesanan gagal diperbarui. Silakan coba kembali.';
        }
    }
}

/*
 * Filter EXISTS + NOT EXISTS mencegah seller melihat atau memproses
 * pesanan yang memiliki item milik toko lain.
 */
$sql = "
    SELECT
        o.id,
        o.created_at,
        o.payment_status,
        o.order_status,
        o.payment_proof,
        o.total,
        u.name AS buyer_name,
        u.email AS buyer_email,
        (
            SELECT GROUP_CONCAT(
                CONCAT(oi.product_name, ' × ', oi.quantity)
                ORDER BY oi.id SEPARATOR ', '
            )
            FROM order_items oi
            WHERE oi.order_id = o.id
              AND oi.seller_id = ?
        ) AS seller_products,
        (
            SELECT COALESCE(SUM(oi.price * oi.quantity), 0)
            FROM order_items oi
            WHERE oi.order_id = o.id
              AND oi.seller_id = ?
        ) AS seller_subtotal
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    WHERE EXISTS (
        SELECT 1
        FROM order_items owned
        WHERE owned.order_id = o.id
          AND owned.seller_id = ?
    )
    AND NOT EXISTS (
        SELECT 1
        FROM order_items other_item
        WHERE other_item.order_id = o.id
          AND (other_item.seller_id IS NULL OR other_item.seller_id <> ?)
    )
    ORDER BY o.created_at DESC, o.id DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute([$uid, $uid, $uid, $uid]);
$orders = $stmt->fetchAll();

$pageTitle = 'Pesanan Toko';
require __DIR__ . '/header.php';
?>

<div class="d-flex align-items-center justify-content-between flex-wrap gap-2 mb-3">
    <div>
        <span class="seller-muted">TRANSAKSI TOKO ANDA</span>
        <h1 class="h3 mb-0">Pesanan Toko</h1>
    </div>
    <span class="seller-role-pill">
        <i class="bi bi-person-check"></i> VERIFIKASI OLEH PENJUAL
    </span>
</div>

<p class="seller-muted">
    Halaman ini hanya menampilkan pesanan yang seluruh produknya berasal dari toko Anda.
    Periksa bukti pembayaran, lalu proses pesanan hingga selesai.
</p>

<?php if ($error !== ''): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<section class="seller-panel">
    <div class="seller-table-wrap">
        <table class="seller-table">
            <thead>
                <tr>
                    <th>Pesanan</th>
                    <th>Pembeli</th>
                    <th>Produk</th>
                    <th>Subtotal Toko</th>
                    <th>Bukti Pembayaran</th>
                    <th>Status</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$orders): ?>
                <tr>
                    <td colspan="7" class="text-center text-muted py-4">
                        Belum ada pesanan untuk toko Anda.
                    </td>
                </tr>
            <?php else: ?>
                <?php foreach ($orders as $order): ?>
                    <tr>
                        <td>
                            <strong>#<?= (int) $order['id'] ?></strong>
                            <br>
                            <small><?= e(date('d/m/Y H:i', strtotime($order['created_at']))) ?></small>
                        </td>
                        <td>
                            <?= e($order['buyer_name']) ?>
                            <br>
                            <small><?= e($order['buyer_email']) ?></small>
                        </td>
                        <td><?= e($order['seller_products'] ?? '-') ?></td>
                        <td><?= rupiah($order['seller_subtotal']) ?></td>
                        <td>
                            <?php if (!empty($order['payment_proof'])): ?>
                                <a href="../uploads/payments/<?= e(rawurlencode(basename($order['payment_proof']))) ?>"
                                   target="_blank" rel="noopener">
                                    <i class="bi bi-image"></i> Lihat bukti
                                </a>
                            <?php else: ?>
                                <span class="text-muted">Belum diunggah</span>
                            <?php endif; ?>
                            <div>
                                <a href="../receipt.php?id=<?= (int) $order['id'] ?>"
                                   target="_blank" rel="noopener">Buka struk</a>
                            </div>
                        </td>
                        <td>
                            <strong><?= e(ucwords(str_replace('_', ' ', $order['payment_status']))) ?></strong>
                            <br>
                            <small><?= e(ucwords(str_replace('_', ' ', $order['order_status']))) ?></small>
                        </td>
                        <td>
                            <div class="seller-actions">
                                <?php if ($order['payment_status'] === 'menunggu_verifikasi'): ?>
                                    <form method="post" onsubmit="return confirm('Verifikasi pembayaran pesanan ini?')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                        <button class="btn btn-success btn-sm" type="submit" name="action" value="approve">
                                            <i class="bi bi-check-lg"></i> Verifikasi
                                        </button>
                                    </form>
                                    <form method="post" onsubmit="return confirm('Tolak bukti pembayaran ini?')">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                        <button class="btn btn-outline-danger btn-sm" type="submit" name="action" value="reject">
                                            <i class="bi bi-x-lg"></i> Tolak
                                        </button>
                                    </form>
                                <?php elseif ($order['payment_status'] === 'berhasil' && $order['order_status'] === 'diproses'): ?>
                                    <form method="post">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                        <button class="btn btn-primary btn-sm" type="submit" name="action" value="ship">
                                            <i class="bi bi-truck"></i> Tandai dikirim
                                        </button>
                                    </form>
                                <?php elseif ($order['payment_status'] === 'berhasil' && $order['order_status'] === 'dikirim'): ?>
                                    <form method="post">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="id" value="<?= (int) $order['id'] ?>">
                                        <button class="btn btn-success btn-sm" type="submit" name="action" value="complete">
                                            <i class="bi bi-check-circle"></i> Selesaikan
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="text-muted">-</span>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>

<?php require __DIR__ . '/footer.php'; ?>
