<?php
require_once __DIR__.'/auth.php';
$uid=(int)user()['id'];
function seller_wallet_balance(PDO $pdo,int $uid): float {
    $q=$pdo->prepare("SELECT COALESCE(SUM(oi.price*oi.quantity),0)
      FROM order_items oi JOIN orders o ON o.id=oi.order_id
      WHERE oi.seller_id=? AND o.payment_status='berhasil' AND o.order_status='selesai'");
    $q->execute([$uid]); $earned=(float)$q->fetchColumn();
    $q=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM seller_withdrawals WHERE seller_id=? AND status IN ('pending','paid')");
    $q->execute([$uid]); return max(0,$earned-(float)$q->fetchColumn());
}
$balance=seller_wallet_balance($pdo,$uid); $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
  $amount=(float)($_POST['amount']??0);
  $bank=trim($_POST['bank_name']??''); $number=trim($_POST['account_number']??''); $holder=trim($_POST['account_holder']??'');
  $note=trim($_POST['seller_note']??'');
  if($amount<=0 || $amount>$balance) $error='Nominal penarikan tidak valid atau melebihi saldo tersedia.';
  elseif($bank===''||$number===''||$holder==='') $error='Lengkapi bank/e-wallet, nomor rekening, dan nama pemilik.';
  elseif(strlen($number)>60||strlen($holder)>120||strlen($note)>500) $error='Data penarikan terlalu panjang.';
  else {
    $q=$pdo->prepare("INSERT INTO seller_withdrawals(seller_id,amount,bank_name,account_number,account_holder,seller_note) VALUES(?,?,?,?,?,?)");
    $q->execute([$uid,$amount,$bank,$number,$holder,$note?:null]);
    flash('Permintaan penarikan saldo berhasil dikirim dan menunggu diproses Super Admin.');
    header('Location: saldo.php'); exit;
  }
}
$q=$pdo->prepare("SELECT * FROM seller_withdrawals WHERE seller_id=? ORDER BY requested_at DESC LIMIT 30");
$q->execute([$uid]); $rows=$q->fetchAll();
$pageTitle='Saldo & Penarikan'; require 'header.php';
?>
<h1 class="h3 mb-4">Saldo & Penarikan</h1>
<section class="seller-stats">
 <article class="seller-stat"><small>Saldo tersedia</small><strong><?=rupiah($balance)?></strong></article>
 <article class="seller-stat"><small>Dasar pencairan</small><strong style="font-size:16px">Pesanan selesai</strong><span class="seller-muted">Pembayaran terverifikasi dan status pesanan selesai.</span></article>
</section>
<section class="seller-panel mt-4">
 <h2 class="h5">Ajukan penarikan</h2>
 <p class="seller-muted">Saldo akan berkurang dari saldo tersedia saat permintaan diajukan. Super Admin memeriksa dan mentransfer secara manual.</p>
 <?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
 <form method="post" class="seller-form">
  <?=csrf_field()?>
  <label>Nominal penarikan (Rp)<input type="number" name="amount" min="1" max="<?=e((string)floor($balance))?>" step="1" required></label>
  <label>Bank / E-Wallet<input name="bank_name" maxlength="80" placeholder="Contoh: BCA / BRI / DANA" required></label>
  <label>Nomor rekening / akun<input name="account_number" maxlength="60" required></label>
  <label>Nama pemilik rekening<input name="account_holder" maxlength="120" required></label>
  <label style="grid-column:1/-1">Catatan (opsional)<input name="seller_note" maxlength="500"></label>
  <div><button class="btn btn-warning" type="submit" <?= $balance<1?'disabled':''?>>Ajukan Penarikan</button></div>
 </form>
</section>
<section class="seller-panel">
 <h2 class="h5">Riwayat penarikan</h2>
 <div class="seller-table-wrap"><table class="seller-table"><thead><tr><th>Tanggal</th><th>Nominal</th><th>Tujuan</th><th>Status</th><th>Catatan Admin</th></tr></thead><tbody>
 <?php foreach($rows as $r):?><tr><td><?=e(date('d/m/Y H:i',strtotime($r['requested_at'])))?></td><td><?=rupiah($r['amount'])?></td><td><?=e($r['bank_name'].' · '.$r['account_number'].' · '.$r['account_holder'])?></td><td><?=e(strtoupper($r['status']))?></td><td><?=e($r['admin_note']?:'-')?></td></tr><?php endforeach;?>
 <?php if(!$rows):?><tr><td colspan="5">Belum ada permintaan penarikan.</td></tr><?php endif;?>
 </tbody></table></div>
</section>
<?php require 'footer.php';?>
