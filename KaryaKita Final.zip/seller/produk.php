<?php
require_once __DIR__.'/auth.php';

$uid = (int) user()['id'];
$error = '';
$edit = null;

if (isset($_GET['edit'])) {
    $q = $pdo->prepare('SELECT * FROM products WHERE id=? AND seller_id=?');
    $q->execute([(int)$_GET['edit'], $uid]);
    $edit = $q->fetch();
    if (!$edit) {
        flash('Produk tidak ditemukan atau bukan milik toko Anda.');
        header('Location: produk.php');
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? 'save';
    $id = (int)($_POST['id'] ?? 0);

    if ($action === 'delete') {
        $q = $pdo->prepare('SELECT image FROM products WHERE id=? AND seller_id=?');
        $q->execute([$id, $uid]);
        $old = $q->fetch();
        if ($old) {
            $del = $pdo->prepare('DELETE FROM products WHERE id=? AND seller_id=?');
            $del->execute([$id, $uid]);
            $path = __DIR__.'/../uploads/products/'.basename((string)$old['image']);
            if ($old['image'] && is_file($path)) @unlink($path);
            flash('Produk berhasil dihapus.');
        }
        header('Location: produk.php');
        exit;
    }

    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $price = filter_var($_POST['price'] ?? null, FILTER_VALIDATE_FLOAT);
    $stock = filter_var($_POST['stock'] ?? null, FILTER_VALIDATE_INT);
    $cat = (int)($_POST['category_id'] ?? 0);
    $image = null;

    if ($name === '' || mb_strlen($name) > 180 || $price === false || $price < 0 || $stock === false || $stock < 0) {
        $error = 'Periksa nama, harga, dan stok.';
    }
    if (!$error && $cat) {
        $q = $pdo->prepare('SELECT id FROM categories WHERE id=?');
        $q->execute([$cat]);
        if (!$q->fetch()) $error = 'Kategori tidak valid.';
    }
    $hasNewImage = isset($_FILES['image']) && (int)($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;

    // Foto wajib saat produk baru dibuat. Saat edit, foto lama boleh dipertahankan.
    if (!$id && !$hasNewImage) {
        $error = 'Foto produk wajib diunggah. Pilih gambar JPG, PNG, atau WebP maksimal 2 MB.';
    }

    if (!$error && $hasNewImage) {
        $uploadError = (int)($_FILES['image']['error'] ?? UPLOAD_ERR_NO_FILE);
        $uploadSize = (int)($_FILES['image']['size'] ?? 0);
        if ($uploadError !== UPLOAD_ERR_OK) {
            $error = ($uploadError === UPLOAD_ERR_INI_SIZE || $uploadError === UPLOAD_ERR_FORM_SIZE)
                ? 'Ukuran foto melebihi batas. Maksimal 2 MB.'
                : 'Foto gagal diunggah. Silakan pilih file gambar kembali.';
        } elseif ($uploadSize <= 0 || $uploadSize > 2 * 1024 * 1024) {
            $error = 'Ukuran foto tidak valid atau melebihi batas maksimal 2 MB.';
        } else {
            $tmpFile = $_FILES['image']['tmp_name'];
            $mime = (new finfo(FILEINFO_MIME_TYPE))->file($tmpFile);
            $types = ['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
            if (!isset($types[$mime])) {
                $error = 'Format foto harus JPG, PNG, atau WebP.';
            } else {
                $uploadDir = __DIR__.'/../uploads/products/';
                if (!is_dir($uploadDir) || !is_writable($uploadDir)) {
                    $error = 'Folder penyimpanan foto produk belum tersedia atau tidak dapat ditulis.';
                } else {
                    $image = 'seller_'.bin2hex(random_bytes(10)).'.'.$types[$mime];
                    if (!move_uploaded_file($tmpFile, $uploadDir.$image)) {
                        $image = null;
                        $error = 'Gagal menyimpan foto produk.';
                    }
                }
            }
        }
    }

    if (!$error) {
        if ($id) {
            $q = $pdo->prepare('SELECT image FROM products WHERE id=? AND seller_id=?');
            $q->execute([$id, $uid]);
            $old = $q->fetch();
            if (!$old) {
                $error = 'Produk tidak ditemukan.';
            } else {
                $final = $image ?: $old['image'];
                $q = $pdo->prepare('UPDATE products SET category_id=?,name=?,description=?,price=?,stock=?,image=? WHERE id=? AND seller_id=?');
                $q->execute([$cat ?: null, $name, $desc, $price, $stock, $final, $id, $uid]);
                if ($image && $old['image']) {
                    @unlink(__DIR__.'/../uploads/products/'.basename($old['image']));
                }
            }
        } else {
            $q = $pdo->prepare('INSERT INTO products(category_id,seller_id,name,description,price,stock,image) VALUES(?,?,?,?,?,?,?)');
            $q->execute([$cat ?: null, $uid, $name, $desc, $price, $stock, $image]);
        }

        if (!$error) {
            flash('Data produk berhasil disimpan.');
            header('Location: produk.php');
            exit;
        }
    }
}

$cats = $pdo->query('SELECT id,name FROM categories ORDER BY name')->fetchAll();
$q = $pdo->prepare('SELECT p.*,c.name category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id WHERE p.seller_id=? ORDER BY p.created_at DESC');
$q->execute([$uid]);
$items = $q->fetchAll();

$pageTitle = 'Produk Saya';
require 'header.php';
?>
<style>
.seller-product-thumb{width:58px;height:58px;object-fit:cover;border-radius:9px;border:1px solid #eadfc9;background:#fff8eb}
.seller-product-actions{display:flex;gap:7px;flex-wrap:wrap;align-items:center}
.seller-product-actions form{margin:0}
.seller-view-btn{white-space:nowrap}
</style>

<h1 class="h3 mb-3">Produk Saya</h1>
<?php if ($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?>

<section class="seller-panel">
    <h2 class="h5"><?= $edit ? 'Edit Produk' : 'Tambah Produk' ?></h2>
    <form method="post" enctype="multipart/form-data" class="seller-form">
        <?=csrf_field()?>
        <input type="hidden" name="id" value="<?=(int)($edit['id'] ?? 0)?>">
        <label>Nama Produk
            <input name="name" maxlength="180" required value="<?=e($edit['name'] ?? '')?>">
        </label>
        <label>Kategori
            <select name="category_id">
                <option value="0">Pilih kategori</option>
                <?php foreach ($cats as $c): ?>
                    <option value="<?=(int)$c['id']?>" <?=(int)($edit['category_id'] ?? 0)===(int)$c['id']?'selected':''?>><?=e($c['name'])?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label>Harga (Rp)
            <input type="number" name="price" min="0" step="0.01" required value="<?=e($edit['price'] ?? '')?>">
        </label>
        <label>Stok
            <input type="number" name="stock" min="0" required value="<?=e($edit['stock'] ?? '0')?>">
        </label>
        <label>Foto produk <small style="display:block;color:#806b55">Wajib untuk produk baru. Format JPG, PNG, atau WebP. Maksimal 2 MB.</small>
            <input type="file" name="image" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" <?= $edit ? '' : 'required' ?>>
            <?php if ($edit && !empty($edit['image'])): ?>
                <small style="display:block;color:#806b55;margin-top:5px">Foto saat ini akan dipertahankan jika tidak memilih gambar baru.</small>
            <?php endif; ?>
        </label>
        <label style="grid-column:1/-1">Deskripsi
            <textarea name="description" rows="3"><?=e($edit['description'] ?? '')?></textarea>
        </label>
        <div class="seller-actions" style="grid-column:1/-1">
            <button class="btn btn-warning" type="submit">Simpan Produk</button>
            <?php if ($edit): ?><a class="btn btn-outline-secondary" href="produk.php">Batal</a><?php endif; ?>
        </div>
    </form>
</section>

<section class="seller-panel">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-3">
        <h2 class="h5 mb-0">Daftar Produk</h2>
        <span class="seller-muted"><?=count($items)?> produk terdaftar</span>
    </div>
    <div class="seller-table-wrap">
        <table class="seller-table">
            <thead>
                <tr>
                    <th>Foto</th><th>Produk</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($items as $p): ?>
                <tr>
                    <td><img class="seller-product-thumb" src="<?=e(image_url($p['image']))?>" alt="<?=e($p['name'])?>"></td>
                    <td><?=e($p['name'])?></td>
                    <td><?=e($p['category_name'] ?? '-')?></td>
                    <td><?=rupiah($p['price'])?></td>
                    <td><?=(int)$p['stock']?></td>
                    <td>
                        <div class="seller-product-actions">
                            <a class="btn btn-sm btn-outline-success seller-view-btn"
                               href="../product.php?id=<?=(int)$p['id']?>"
                               target="_blank" rel="noopener"
                               title="Lihat tampilan produk di marketplace">
                                <i class="bi bi-eye"></i> Lihat
                            </a>
                            <a class="btn btn-sm btn-outline-primary" href="?edit=<?=(int)$p['id']?>">
                                <i class="bi bi-pencil"></i> Edit
                            </a>
                            <form method="post" onsubmit="return confirm('Hapus produk ini?')">
                                <?=csrf_field()?>
                                <input type="hidden" name="id" value="<?=(int)$p['id']?>">
                                <button class="btn btn-sm btn-outline-danger" name="action" value="delete">
                                    <i class="bi bi-trash"></i> Hapus
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if (!$items): ?>
                    <tr><td colspan="6">Belum ada produk.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</section>
<?php require 'footer.php'; ?>
