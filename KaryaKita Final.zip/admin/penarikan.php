<?php
require_once __DIR__.'/auth.php';
$pageTitle='Penarikan Penjual'; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 $id=(int)($_POST['id']??0); $action=$_POST['action']??''; $note=trim($_POST['admin_note']??'');
 if($id<1||!in_array($action,['paid','rejected'],true)) $error='Permintaan tidak valid.';
 else {
  try {
   $pdo->beginTransaction();
   $q=$pdo->prepare("SELECT * FROM seller_withdrawals WHERE id=? AND status='pending' FOR UPDATE");
   $q->execute([$id]); $w=$q->fetch();
   if(!$w) throw new Exception('Permintaan sudah diproses atau tidak ditemukan.');
   if($action==='paid'){
    // Penandaan paid dilakukan setelah Super Admin benar-benar mentransfer dana.
    $u=$pdo->prepare("UPDATE seller_withdrawals SET status='paid',admin_note=?,processed_at=NOW(),processed_by=? WHERE id=? AND status='pending'");
   } else {
    $u=$pdo->prepare("UPDATE seller_withdrawals SET status='rejected',admin_note=?,processed_at=NOW(),processed_by=? WHERE id=? AND status='pending'");
   }
   $u->execute([$note?:null,(int)user()['id'],$id]);
   if(!$u->rowCount()) throw new Exception('Status gagal diperbarui.');
   $pdo->commit(); flash($action==='paid'?'Penarikan ditandai sudah dibayar.':'Permintaan penarikan ditolak.');
   header('Location: penarikan.php'); exit;
  } catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();$error=$e->getMessage();}
 }
}
$rows=$pdo->query("SELECT w.*,u.name,u.email,u.store_name FROM seller_withdrawals w JOIN users u ON u.id=w.seller_id ORDER BY CASE w.status WHEN 'pending' THEN 0 ELSE 1 END,w.requested_at DESC LIMIT 200")->fetchAll();
require __DIR__.'/header.php';
?>
<section class="admin-page-heading"><div><span class="admin-eyebrow">PENGELOLAAN SALDO</span><h1>Penarikan Penjual</h1><p>Periksa permintaan pencairan saldo dari masing-masing toko.</p></div></section>
<?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<section class="admin-card"><div class="admin-table-wrap"><table class="admin-table"><thead><tr><th>Penjual</th><th>Nominal</th><th>Tujuan transfer</th><th>Tanggal</th><th>Status</th><th>Tindakan</th></tr></thead><tbody>
<?php foreach($rows as $r):?><tr>
<td><strong><?=e($r['store_name']?:$r['name'])?></strong><small class="admin-cell-sub"><?=e($r['email'])?></small></td>
<td><strong><?=rupiah($r['amount'])?></strong></td>
<td><?=e($r['bank_name'].' / '.$r['account_number'])?><small class="admin-cell-sub"><?=e($r['account_holder'])?></small></td>
<td><?=e(date('d/m/Y H:i',strtotime($r['requested_at'])))?></td><td><?=e(strtoupper($r['status']))?></td>
<td><?php if($r['status']==='pending'):?><form method="post" class="d-grid gap-1"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$r['id']?>"><input class="form-control form-control-sm" name="admin_note" maxlength="500" placeholder="Catatan / referensi transfer"><button class="btn btn-success btn-sm" name="action" value="paid" onclick="return confirm('Pastikan transfer sudah dilakukan. Tandai dibayar?')">Tandai sudah ditransfer</button><button class="btn btn-outline-danger btn-sm" name="action" value="rejected" onclick="return confirm('Tolak permintaan penarikan ini?')">Tolak</button></form><?php else:?><?=e($r['admin_note']?:'-')?><?php endif;?></td>
</tr><?php endforeach;?>
<?php if(!$rows):?><tr><td colspan="6">Belum ada permintaan penarikan.</td></tr><?php endif;?>
</tbody></table></div></section>
<?php require __DIR__.'/footer.php';?>
