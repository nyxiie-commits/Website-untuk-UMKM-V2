<?php
require_once __DIR__ . '/auth.php';
$pageTitle = 'Pesanan KaryaKita Official';
$error = '';
$officialId = official_seller_id($pdo);
if ($officialId <= 0) { http_response_code(500); exit('Akun pemilik produk KaryaKita Official belum tersedia.'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $action = $_POST['action'] ?? '';
    if ($id <= 0 || !order_belongs_to_seller($pdo, $id, $officialId)) {
        $error = 'Pesanan ini bukan transaksi KaryaKita Official.';
    } else {
        try {
            if ($action === 'approve') {
                $stmt = $pdo->prepare("UPDATE orders SET payment_status='berhasil',order_status='diproses',paid_at=NOW() WHERE id=? AND payment_status='menunggu_verifikasi'");
                $stmt->execute([$id]);
            } elseif ($action === 'reject') {
                $stmt = $pdo->prepare("UPDATE orders SET payment_status='ditolak',order_status='menunggu_pembayaran' WHERE id=? AND payment_status='menunggu_verifikasi'");
                $stmt->execute([$id]);
            } elseif ($action === 'ship') {
                $stmt = $pdo->prepare("UPDATE orders SET order_status='dikirim' WHERE id=? AND payment_status='berhasil' AND order_status='diproses'");
                $stmt->execute([$id]);
            } elseif ($action === 'complete') {
                $stmt = $pdo->prepare("UPDATE orders SET order_status='selesai' WHERE id=? AND payment_status='berhasil' AND order_status='dikirim'");
                $stmt->execute([$id]);
            } else { $error = 'Aksi pesanan tidak dikenali.'; }
            if (!$error) {
                flash($stmt->rowCount() ? 'Status pesanan KaryaKita Official berhasil diperbarui.' : 'Tidak ada perubahan status pesanan.');
                header('Location: pesanan.php'); exit;
            }
        } catch (PDOException $e) {
            error_log('[KaryaKita official orders] '.$e->getMessage());
            $error='Status pesanan gagal diperbarui.';
        }
    }
}
$filter=$_GET['status']??'';
$allowed=['menunggu_pembayaran','menunggu_verifikasi','berhasil','ditolak'];
$sql="SELECT o.*,u.name customer_name,u.email customer_email,
      (SELECT GROUP_CONCAT(CONCAT(oi.product_name,' × ',oi.quantity) SEPARATOR ', ') FROM order_items oi WHERE oi.order_id=o.id) products
      FROM orders o JOIN users u ON u.id=o.user_id
      WHERE EXISTS (SELECT 1 FROM order_items x WHERE x.order_id=o.id)
      AND NOT EXISTS (SELECT 1 FROM order_items x WHERE x.order_id=o.id AND (x.seller_id IS NULL OR x.seller_id<>?))";
$params=[$officialId];
if(in_array($filter,$allowed,true)){$sql.=' AND o.payment_status=?';$params[]=$filter;}
$sql.=' ORDER BY o.created_at DESC';
$stmt=$pdo->prepare($sql);$stmt->execute($params);$orders=$stmt->fetchAll();
function order_payment_label(string $status): string {
 return match($status){'berhasil'=>'Terverifikasi','menunggu_verifikasi'=>'Menunggu verifikasi','ditolak'=>'Ditolak',default=>'Menunggu pembayaran'};
}
function order_badge_class(string $status): string {
 return match($status){'berhasil'=>'status-success','ditolak'=>'status-danger','menunggu_verifikasi','menunggu_pembayaran'=>'status-warning',default=>'status-info'};
}
require __DIR__.'/header.php';
?>
<section class="admin-page-heading"><div><span class="admin-eyebrow">TRANSAKSI KARYAKITA OFFICIAL</span><h1>Pesanan Official</h1><p>Halaman ini hanya memproses pesanan produk yang dijual langsung oleh KaryaKita Official. Pesanan toko mitra diproses oleh penjual masing-masing.</p></div></section>
<?php if($error):?><div class="alert alert-danger"><?=e($error)?></div><?php endif;?>
<section class="admin-card">
 <div class="admin-filter-row">
 <?php foreach([''=>'Semua','menunggu_verifikasi'=>'Menunggu verifikasi','berhasil'=>'Terverifikasi','ditolak'=>'Ditolak','menunggu_pembayaran'=>'Belum dibayar'] as $key=>$label):?>
 <a class="<?= $filter===$key?'selected':''?>" href="<?= $key===''?'pesanan.php':'?status='.e($key)?>"><?=e($label)?></a>
 <?php endforeach;?>
 </div>
 <?php if(!$orders):?><div class="admin-empty"><i class="bi bi-receipt"></i><p>Belum ada transaksi KaryaKita Official pada filter ini.</p></div>
 <?php else:?><div class="admin-table-wrap"><table class="admin-table admin-orders-table">
 <thead><tr><th>Pesanan</th><th>Pelanggan</th><th>Produk Official</th><th>Total</th><th>Bukti Pembayaran</th><th>Status</th><th>Tindakan</th></tr></thead><tbody>
 <?php foreach($orders as $o):?><tr>
 <td><strong>#<?=(int)$o['id']?></strong><small class="admin-cell-sub"><?=e(date('d M Y, H:i',strtotime($o['created_at'])))?></small></td>
 <td><strong><?=e($o['customer_name'])?></strong><small class="admin-cell-sub"><?=e($o['customer_email'])?></small></td>
 <td><?=e($o['products']??'Produk KaryaKita Official')?></td><td><strong><?=rupiah($o['total'])?></strong></td>
 <td><?php if($o['payment_proof']):?><a class="admin-text-link" href="../uploads/payments/<?=e(rawurlencode(basename($o['payment_proof'])))?>" target="_blank" rel="noopener"><i class="bi bi-image"></i> Lihat bukti</a><?php else:?><span class="text-muted">Belum diunggah</span><?php endif;?><div><a class="admin-sub-link" href="../receipt.php?id=<?=(int)$o['id']?>" target="_blank">Buka struk</a></div></td>
 <td><span class="admin-status <?=order_badge_class($o['payment_status'])?>"><?=e(order_payment_label($o['payment_status']))?></span><small class="admin-cell-sub"><?=e(ucwords(str_replace('_',' ',$o['order_status'])))?></small></td>
 <td><div class="admin-order-actions">
 <?php if($o['payment_status']==='menunggu_verifikasi'):?>
 <form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$o['id']?>"><button class="admin-button admin-button-success admin-button-sm" name="action" value="approve">Setujui</button></form>
 <form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$o['id']?>"><button class="admin-button admin-button-danger admin-button-sm" name="action" value="reject">Tolak</button></form>
 <?php elseif($o['payment_status']==='berhasil'&&$o['order_status']==='diproses'):?><form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$o['id']?>"><button class="admin-button admin-button-primary admin-button-sm" name="action" value="ship">Tandai dikirim</button></form>
 <?php elseif($o['payment_status']==='berhasil'&&$o['order_status']==='dikirim'):?><form method="post"><?=csrf_field()?><input type="hidden" name="id" value="<?=(int)$o['id']?>"><button class="admin-button admin-button-success admin-button-sm" name="action" value="complete">Selesaikan</button></form>
 <?php else:?><span class="text-muted">-</span><?php endif;?>
 </div></td></tr><?php endforeach;?>
 </tbody></table></div><?php endif;?>
</section>
<?php require __DIR__.'/footer.php';?>
