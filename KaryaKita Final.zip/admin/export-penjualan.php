<?php
declare(strict_types=1);

require_once __DIR__ . '/auth.php';
need_admin();

function valid_date_input(?string $value): ?string {
    if (!$value) return null;
    $date = DateTime::createFromFormat('Y-m-d', $value);
    return $date && $date->format('Y-m-d') === $value ? $value : null;
}
function xlsx_xml(string $value): string {
    return htmlspecialchars($value, ENT_XML1 | ENT_COMPAT, 'UTF-8');
}
function xlsx_col(int $number): string {
    $name = '';
    while ($number > 0) {
        $mod = ($number - 1) % 26;
        $name = chr(65 + $mod) . $name;
        $number = intdiv($number - 1, 26);
    }
    return $name;
}
/** Build a ZIP archive without requiring the PHP ZipArchive extension. */
function xlsx_zip(array $files): string {
    $body = '';
    $central = '';
    $offset = 0;
    $count = 0;
    foreach ($files as $name => $data) {
        $name = str_replace('\\', '/', $name);
        $compressed = gzdeflate($data, 6);
        if ($compressed === false) throw new RuntimeException('Gagal mengompres file Excel.');
        $crc = crc32($data);
        $size = strlen($data);
        $compressedSize = strlen($compressed);
        $nameLength = strlen($name);
        $local = pack('VvvvvvVVVvv', 0x04034b50, 20, 0, 8, 0, 0, $crc, $compressedSize, $size, $nameLength, 0) . $name . $compressed;
        $body .= $local;
        $central .= pack('VvvvvvvVVVvvvvvVV', 0x02014b50, 20, 20, 0, 8, 0, 0, $crc, $compressedSize, $size, $nameLength, 0, 0, 0, 0, 0, $offset) . $name;
        $offset += strlen($local);
        $count++;
    }
    $centralOffset = strlen($body);
    $centralSize = strlen($central);
    $end = pack('VvvvvVVv', 0x06054b50, 0, 0, $count, $count, $centralSize, $centralOffset, 0);
    return $body . $central . $end;
}

$startDate = valid_date_input($_GET['dari'] ?? null);
$endDate = valid_date_input($_GET['sampai'] ?? null);
if (!empty($_GET['dari']) && !$startDate) { http_response_code(400); exit('Format tanggal awal tidak valid.'); }
if (!empty($_GET['sampai']) && !$endDate) { http_response_code(400); exit('Format tanggal akhir tidak valid.'); }
if ($startDate && $endDate && $startDate > $endDate) { http_response_code(400); exit('Tanggal awal tidak boleh melebihi tanggal akhir.'); }

$sql = "
    SELECT o.id, o.created_at, u.name AS customer_name, u.email AS customer_email,
           o.phone, o.address, o.payment_method, o.payment_status, o.order_status,
           o.subtotal, o.shipping_courier, o.shipping_cost, o.total,
           COALESCE(SUM(oi.quantity), 0) AS total_items,
           GROUP_CONCAT(CONCAT(oi.product_name, ' (', oi.quantity, ' x ', oi.price, ')') ORDER BY oi.id SEPARATOR '; ') AS product_details
    FROM orders o
    INNER JOIN users u ON u.id = o.user_id
    LEFT JOIN order_items oi ON oi.order_id = o.id
    WHERE o.payment_status = 'berhasil'";
$params = [];
if ($startDate) { $sql .= ' AND o.created_at >= ?'; $params[] = $startDate . ' 00:00:00'; }
if ($endDate) { $sql .= ' AND o.created_at <= ?'; $params[] = $endDate . ' 23:59:59'; }
$sql .= " GROUP BY o.id, o.created_at, u.name, u.email, o.phone, o.address,
          o.payment_method, o.payment_status, o.order_status, o.subtotal,
          o.shipping_courier, o.shipping_cost, o.total
          ORDER BY o.created_at DESC, o.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$headers = [
    'No. Pesanan', 'Tanggal Pesanan', 'Nama Pelanggan', 'Email', 'No. Telepon',
    'Alamat Pengiriman', 'Rincian Produk', 'Jumlah Produk', 'Harga Produk / Subtotal (Rp)',
    'Ekspedisi', 'Ongkir (Rp)', 'Total Bersih (Rp)', 'Metode Pembayaran',
    'Status Pembayaran', 'Status Pesanan'
];
$allRows = [$headers];
foreach ($rows as $r) {
    $allRows[] = [
        (string)$r['id'], (string)$r['created_at'], (string)$r['customer_name'],
        (string)$r['customer_email'], (string)$r['phone'], (string)$r['address'],
        (string)($r['product_details'] ?? ''), (int)$r['total_items'],
        (float)$r['subtotal'], (string)$r['shipping_courier'], (float)$r['shipping_cost'],
        (float)$r['total'], (string)$r['payment_method'], (string)$r['payment_status'],
        (string)$r['order_status']
    ];
}

$xmlRows = '';
foreach ($allRows as $ri => $row) {
    $rowNum = $ri + 1;
    $xmlRows .= '<row r="' . $rowNum . '">';
    foreach ($row as $ci => $value) {
        $cell = xlsx_col($ci + 1) . $rowNum;
        if ($ri === 0) {
            $xmlRows .= '<c r="' . $cell . '" s="1" t="inlineStr"><is><t>' . xlsx_xml((string)$value) . '</t></is></c>';
        } elseif (in_array($ci, [7, 8, 10, 11], true)) {
            $style = in_array($ci, [8, 10, 11], true) ? ' s="2"' : '';
            $xmlRows .= '<c r="' . $cell . '"' . $style . '><v>' . (is_numeric($value) ? (string)$value : '0') . '</v></c>';
        } else {
            $xmlRows .= '<c r="' . $cell . '" t="inlineStr"><is><t xml:space="preserve">' . xlsx_xml((string)$value) . '</t></is></c>';
        }
    }
    $xmlRows .= '</row>';
}
$lastRow = count($allRows);
$widths = [14, 21, 24, 30, 18, 42, 48, 14, 25, 22, 16, 20, 22, 20, 18];
$cols = '<cols>';
foreach ($widths as $i => $width) $cols .= '<col min="' . ($i + 1) . '" max="' . ($i + 1) . '" width="' . $width . '" customWidth="1"/>';
$cols .= '</cols>';
$sheet = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
    . '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
    . '<sheetViews><sheetView showGridLines="1" workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
    . '<sheetFormatPr defaultRowHeight="18"/>' . $cols . '<sheetData>' . $xmlRows . '</sheetData>'
    . '<autoFilter ref="A1:O' . max(1, $lastRow) . '"/><pageMargins left="0.25" right="0.25" top="0.5" bottom="0.5" header="0.2" footer="0.2"/>'
    . '</worksheet>';

$files = [
    '[Content_Types].xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>',
    '_rels/.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>',
    'xl/workbook.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Laporan Penjualan" sheetId="1" r:id="rId1"/></sheets></workbook>',
    'xl/_rels/workbook.xml.rels' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>',
    'xl/styles.xml' => '<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><numFmts count="1"><numFmt numFmtId="164" formatCode="&quot;Rp&quot; #,##0.00"/></numFmts><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF8A4B08"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="2"><border/><border><bottom style="thin"><color rgb="FFD9C7A8"/></bottom></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="3"><xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="1" xfId="0" applyAlignment="1"><alignment vertical="center" wrapText="1"/></xf><xf numFmtId="164" fontId="0" fillId="0" borderId="1" xfId="0" applyNumberFormat="1"/></cellXfs></styleSheet>',
    'xl/worksheets/sheet1.xml' => $sheet
];

try { $xlsx = xlsx_zip($files); }
catch (Throwable $e) { http_response_code(500); exit('Gagal membuat file Excel.'); }
$filename = 'laporan-penjualan-karyakita-' . date('Ymd-His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($xlsx));
header('Cache-Control: max-age=0');
echo $xlsx;
exit;
