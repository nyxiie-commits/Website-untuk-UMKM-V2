<?php
require_once __DIR__ . '/auth.php';

$filter = $_GET['role'] ?? 'all';
$allowed = ['all','super_admin','seller','buyer'];
if (!in_array($filter,$allowed,true)) $filter='all';
$search = trim($_GET['q'] ?? '');

$where=[]; $params=[];
if ($filter !== 'all') { $where[]='u.role=?'; $params[]=$filter; }
if ($search !== '') {
    $where[]='(u.name LIKE ? OR u.email LIKE ? OR u.store_name LIKE ?)';
    $like='%'.$search.'%'; array_push($params,$like,$like,$like);
}
$sql="SELECT u.id,u.name,u.email,u.role,u.store_name,u.seller_status,u.created_at,
      (SELECT COUNT(*) FROM products p WHERE p.seller_id=u.id) AS product_count
      FROM users u";
if ($where) $sql.=' WHERE '.implode(' AND ',$where);
$sql.=" ORDER BY FIELD(u.role,'super_admin','seller','buyer'),u.created_at DESC";
$stmt=$pdo->prepare($sql);$stmt->execute($params);$users=$stmt->fetchAll();

$counts=[
 'super_admin'=>(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role IN ('super_admin','admin')")->fetchColumn(),
 'seller'=>(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='seller'")->fetchColumn(),
 'buyer'=>(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='buyer'")->fetchColumn()
];
$pageTitle='Semua Pengguna';require 'header.php';
?>
<section class="admin-page-heading">
 <div><span class="admin-eyebrow">IDENTITAS & AKSES</span><h1>Semua Pengguna</h1><p>Kenali setiap akun berdasarkan peran dan statusnya di KaryaKita.</p></div>
</section>
<section class="admin-stat-grid">
 <article class="admin-stat-card"><span class="admin-stat-icon icon-gold"><i class="bi bi-shield-lock"></i></span><div><small>Super Admin</small><strong><?=number_format($counts['super_admin'])?></strong><span>Pengelola utama</span></div></article>
 <article class="admin-stat-card"><span class="admin-stat-icon icon-blue"><i class="bi bi-shop"></i></span><div><small>Penjual</small><strong><?=number_format($counts['seller'])?></strong><span>Seluruh akun toko</span></div></article>
 <article class="admin-stat-card"><span class="admin-stat-icon icon-green"><i class="bi bi-bag-heart"></i></span><div><small>Pembeli</small><strong><?=number_format($counts['buyer'])?></strong><span>Akun pelanggan</span></div></article>
</section>
<section class="admin-card">
 <div class="admin-card-heading"><div><h2>Direktori Akun</h2><p>Identitas akun ditentukan oleh role yang tersimpan di database.</p></div></div>
 <form method="get" class="d-flex gap-2 flex-wrap mb-3">
  <input class="form-control" style="max-width:320px" type="search" name="q" value="<?=e($search)?>" placeholder="Cari nama, email, atau toko">
  <select class="form-select" style="max-width:210px" name="role">
   <option value="all" <?=$filter==='all'?'selected':''?>>Semua role</option>
   <option value="super_admin" <?=$filter==='super_admin'?'selected':''?>>Super Admin</option>
   <option value="seller" <?=$filter==='seller'?'selected':''?>>Penjual</option>
   <option value="buyer" <?=$filter==='buyer'?'selected':''?>>Pembeli</option>
  </select>
  <button class="admin-button admin-button-primary" type="submit"><i class="bi bi-search"></i> Cari</button>
  <a class="admin-button" href="pengguna.php">Reset</a>
 </form>
 <div class="admin-table-wrap"><table class="admin-table">
  <thead><tr><th>Pengguna</th><th>Identitas Role</th><th>Nama Toko</th><th>Produk</th><th>Status</th><th>Bergabung</th></tr></thead>
  <tbody>
  <?php foreach($users as $u): $meta=role_meta($u['role']); ?>
   <tr>
    <td><strong><?=e($u['name'])?></strong><small class="admin-cell-sub"><?=e($u['email'])?></small></td>
    <td><span class="admin-role-label admin-role-<?=e($meta['tone'])?>"><i class="bi <?=e($meta['icon'])?>"></i> <?=e($meta['label'])?></span></td>
    <td><?=e($u['store_name']?:'—')?></td>
    <td><?=(int)$u['product_count']?></td>
    <td>
      <?php if($u['role']==='seller'): ?>
       <span class="admin-status-pill <?= $u['seller_status']==='approved'?'is-approved':($u['seller_status']==='pending'?'is-pending':'is-inactive') ?>"><?=e(ucfirst($u['seller_status']??'pending'))?></span>
      <?php elseif(in_array($u['role'],['super_admin','admin'],true)): ?>
       <span class="admin-status-pill is-approved">Aktif</span>
      <?php else: ?><span class="admin-status-pill is-approved">Aktif</span><?php endif;?>
    </td>
    <td><?=e(date('d/m/Y',strtotime($u['created_at'])))?></td>
   </tr>
  <?php endforeach;?>
  <?php if(!$users):?><tr><td colspan="6">Tidak ada pengguna yang cocok dengan pencarian.</td></tr><?php endif;?>
  </tbody>
 </table></div>
</section>
<style>
.admin-role-label{display:inline-flex;align-items:center;gap:6px;padding:6px 9px;border-radius:999px;font-size:10px;font-weight:800;letter-spacing:.04em;white-space:nowrap}
.admin-role-admin{background:#fff0cf;color:#8a5a08;border:1px solid #efd18c}
.admin-role-seller{background:#e8f1ff;color:#245b9c;border:1px solid #c7dcfb}
.admin-role-buyer{background:#e7f6eb;color:#237343;border:1px solid #c6e8d0}
.admin-role-guest{background:#eee;color:#555}
.admin-status-pill{display:inline-block;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:700}
.admin-status-pill.is-approved{background:#e7f6eb;color:#237343}
.admin-status-pill.is-pending{background:#fff2d8;color:#946200}
.admin-status-pill.is-inactive{background:#fde8e8;color:#a33131}
</style>
<?php require 'footer.php';?>
