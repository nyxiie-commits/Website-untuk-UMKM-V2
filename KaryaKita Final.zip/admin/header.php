<?php
require_once __DIR__ . '/auth.php';

$adminPage = basename($_SERVER['PHP_SELF'] ?? 'index.php');
$adminNav = [
    'index.php' => ['label' => 'Dashboard', 'icon' => 'bi-grid-1x2'],
    'produk.php' => ['label' => 'Produk', 'icon' => 'bi-box-seam'],
    'kategori.php' => ['label' => 'Kategori', 'icon' => 'bi-tags'],
    'pesanan.php' => ['label' => 'Pesanan Official', 'icon' => 'bi-receipt'],
    'penarikan.php' => ['label' => 'Penarikan Penjual', 'icon' => 'bi-wallet2'],
    'penjual.php' => ['label' => 'Penjual', 'icon' => 'bi-shop'],
    'pengguna.php' => ['label' => 'Semua Pengguna', 'icon' => 'bi-people'],
];
$adminNotice = flash();
?>
<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle ?? 'Admin') ?> | KaryaKita Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="../assets/css/admin.css" rel="stylesheet">
<style>.admin-role-pill{display:inline-flex;align-items:center;gap:5px;padding:4px 8px;border-radius:999px;background:#fff0cf;color:#8a5a08;border:1px solid #efd18c;font-size:10px;font-weight:800;letter-spacing:.05em;margin-top:4px}</style></head>
<body class="admin-body">
<div class="admin-layout">
    <aside class="admin-sidebar">
        <a class="admin-brand" href="index.php">
            <span class="admin-brand-mark">K</span>
            <span><strong>KaryaKita</strong><small>ADMIN PANEL</small></span>
        </a>

        <div class="admin-menu-label">MENU UTAMA</div>
        <nav class="admin-menu" aria-label="Menu admin">
            <?php foreach ($adminNav as $file => $item): ?>
                <a href="<?= e($file) ?>" class="<?= $adminPage === $file ? 'active' : '' ?>">
                    <i class="bi <?= e($item['icon']) ?>"></i>
                    <span><?= e($item['label']) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="admin-sidebar-bottom">
            <a href="../index.php" target="_blank" rel="noopener">
                <i class="bi bi-shop"></i><span>Lihat Website</span>
            </a>
            <a href="../logout.php">
                <i class="bi bi-box-arrow-right"></i><span>Keluar</span>
            </a>
        </div>
    </aside>

    <div class="admin-main-wrap">
        <header class="admin-topbar">
            <div>
                <span class="admin-topbar-kicker">RUANG KERJA ADMIN</span>
                <strong><?= e($adminNav[$adminPage]['label'] ?? 'KaryaKita') ?></strong>
            </div>
            <div class="admin-user">
                <span class="admin-user-icon"><i class="bi bi-person"></i></span>
                <span><strong><?= e(user()['name'] ?? 'Admin') ?></strong><small><span class="admin-role-pill"><i class="bi bi-shield-lock-fill"></i> SUPER ADMIN</span></small></span>
            </div>
        </header>

        <main class="admin-content">
            <?php if ($adminNotice): ?>
                <div class="alert alert-warning admin-alert" role="alert">
                    <i class="bi bi-info-circle me-2"></i><?= e($adminNotice) ?>
                </div>
            <?php endif; ?>
