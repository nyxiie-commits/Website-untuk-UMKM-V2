PEMBARUAN ADMIN KARYAKITA
=========================

Isi paket:
- admin/header.php
- admin/footer.php
- admin/auth.php
- admin/index.php
- admin/produk.php
- admin/kategori.php
- admin/pesanan.php
- assets/css/admin.css

Cara pemasangan:
1. Backup folder admin yang sedang ada di htdocs.
2. Upload folder admin dari paket ini ke htdocs dan timpa file admin yang lama.
3. Upload assets/css/admin.css ke htdocs/assets/css/admin.css.
4. Jangan timpa config.php, functions.php, database, atau folder uploads.
5. Buka https://domain-anda/admin/ lalu login sebagai akun admin.
6. Uji dashboard, tambah/edit/hapus produk, tambah/edit/hapus kategori, serta alur verifikasi dan pengiriman pesanan.

Catatan:
- Paket ini tidak memerlukan migrasi SQL.
- Paket ini tidak menyentuh data produk, kategori, akun, pesanan, atau bukti pembayaran.
- Grafik dashboard memakai Chart.js CDN sehingga memerlukan koneksi internet.
- Fitur pengaturan tampilan toko dan manajemen pengguna belum ditambahkan pada paket ini karena belum ada tabel/aturan pengaturan khusus di database sumber.
- Pastikan konfigurasi database aktif di config.php hosting. Jangan upload file konfigurasi yang berisi password ke tempat publik.
